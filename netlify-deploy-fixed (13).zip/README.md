# Probaho Remit — Titan Edition

**Your AI-powered cross-border finance companion.**
*Send smarter. Spot scams. Protect every transfer.*

An explicitly **simulated** fintech demo built for the **2026 Shenzhen International FinTech
Competition** (International Track, Topic C — *AI as a Financial Participant*).

> **Simulation disclosure.** Rates, fees, provider comparisons, FX history, AI responses and risk
> scores are illustrative synthetic data — not live financial offers. No money is moved, and no
> payment instructions are verified with a bank or university. Independently confirm recipient
> details and obtain current quotes from authorised providers before making a real payment.

## Complete Screen Catalogue (100% Match to Reference Images)

| # | Screen Name | Route | Reference Source | Key Features & Exact Data |
|---|---|---|---|---|
| 1 | **Public Landing Page** | `#/home` | Images 2 & 3 (Screen 1) | Cosmic hero, "Smarter Transfers. Safer Journeys.", $1,000 USD → 119,480 BDT calculator, Harvard/MIT/Toronto/Melbourne badges |
| 2 | **User Dashboard** | `#/dashboard` | Image 1 & Images 2-3 (Screen 2) | 4 KPI Cards: **2,847 Users**, **18,429 Txns**, **$24,680 Revenue**, **1,203 Active Today**; SVG Line Chart; 4-slice Donut Chart; Recent Txns table; Quick Actions |
| 3 | **Transfer Optimizer** | `#/corridor-optimizer` | Images 2 & 3 (Screen 3) | 4-step wizard: Details → Compare → Review → Confirm. WorldRemit ($4.99 fee), Wise ($4.50 fee), Remitly ($7.50 fee), Western Union ($12.00 fee) |
| 4 | **Tuition Planner** | `#/tuition-planner` | Images 2 & 3 (Screen 4) | U of Toronto Computer Science, Jan 2027 start; **$45,000 CAD** annual estimate; **72% Funded** radial meter; 4-year bar chart ($252k total) |
| 5 | **ScamShield** | `#/scamshield` | Images 2 & 3 (Screen 5) | **92/100 Low Risk** circular score; Recent security alerts; Safety tips checklist; interactive heuristic scam text analyzer |
| 6 | **FX Advisor & Rates** | `#/rates` | Images 2 & 3 (Screen 6) | Live currency board (USD, EUR, GBP, CAD, AUD, SAR, MYR); 90-day historical chart; USD strengthening market insight |
| 7 | **Document Vault** | `#/payment-vault` | Images 2 & 3 (Screen 7) | Verified cards for Passport, National ID, Visa, Admission Letter; upload document modal; downloadable simulated receipts |
| 8 | **Ask Probaho Copilot** | `#/ask-probaho` | Images 2 & 3 (Screen 8) | Interactive AI Assistant; *"What's the best way to send $500 to Bangladesh?"*; Actionable `[Yes, create transfer]` and `[Show more options]` buttons |
| 9 | **Multi-Device Responsive Web** | Responsive on all screens | All Devices | Fluid adaptive layout across mobile phones (360-480px), tablets (768-1024px), laptops (1200px), and wide PCs; zero fake simulator needed |
| 10 | **Admin Portal (Dark Mode)** | `#/admin` | Images 2 & 3 (Screen 10) | Cyber-dark command center: **12,480 Users**, **48,729 Txns**, **$2,480,680 Volume**, **24 Pending KYC**; glowing trend line & donut |
| 11 | **KYC Queue** | `#/admin/kyc` | Images 2 & 3 (Screen 11) | Review queue: Imran Hossain, Fatima Ahmed, Zayed Khan, Meherik Akhtar, Rashidul Islam; interactive applicant review modal |
| 12 | **Audit Logs** | `#/admin/audit` | Images 2 & 3 (Screen 12) | System audit trails: Oct 12 timestamps, Admin/Editor actors, User Updated, KYC Approved, IP addresses (123.45.67.2) |
| 13 | **System Settings** | `#/admin/settings` | Images 2 & 3 (Screen 13) | Platform configuration tabs: General, Security, Integrations, Notifications; maintenance mode toggle; support email |
| 14 | **User Management** | `#/admin/users` | Image 1 (Screen 3) | Isolated high-security admin sub-module: All Users (124), Admins (8), Members (116) filter tabs; avatar table with Rahim Uddin, Ayesha Khan, etc. |
| 15 | **Transactions Ledger** | `#/transactions` | Image 1 (Screen 4) | Comprehensive transactions table with Type filters, Status filters, Date picker, CSV Export, and New Transaction modal |
| 16 | **Analytics & Reports** | `#/analytics` | Image 1 (Screen 5) | Revenue overview area curve, Conversion rate 3.2%, Top Products/Services donut breakdown (Deposit 42%, Withdrawal 28%, Transfer 18%, Payment 12%) |
| 17 | **Backend Architecture** | `#/architecture` | Image 1 (Architecture) | Complete interactive diagrams of Client layer, API Layer (Node + Express), PostgreSQL DB, Supabase Auth, DB ER schema, and Tech Stack |
| 18 | **Modern Sign-In** | `#/sign-in` | Image 1 (Screen 2) | Split screen login: dark security features banner on left, white clean form on right, show/hide password toggle, Google sign-in |

## Instant Run & 10000000% Access

Everything is pre-built and runs immediately with zero external dependencies:

- **Local Server**: Run `node server.js` and open `http://127.0.0.1:3000/` in any browser.
- **Direct File**: You can also double-click `index.html` to open directly in Chrome, Edge, Safari, or Firefox.
- **Screen Navigator**: A persistent top dropdown ("⚡ Quick Switch Screen") allows you to jump directly to any of the 18 views with a single click.
- **Unrestricted Access**: Full administrative, student, and explorer access is unlocked by default under **Fahad Ahmed (Admin / Student)**.

## The five-minute demo

See **DEMO_SCRIPT.md** — presenter dialogue, exact clicks and inputs, expected numbers, fallbacks.
Technical beat-map in `docs/DEMO_FLOW.md`.

## How seeded data works

- Corridors/providers/ledger/tuition: fixed seed files in `data/`.
- FX history: generated deterministically at runtime (mulberry32, per-corridor seed) — same
  series on every machine, every load.
- Draft references: `TX-DEMO-XXXXX`, hashed from canonical draft inputs (deterministic).
- Reset anytime: Tuition Planner → "Reset demo data" (or Vault → same).

## Financial assumptions

`js/config/demo-config.js` is the single source: fee model
(`percentageFee = principal × pctFee`; pct deducted from principal; flat charged on top),
spread convention (`customerRate = mid × (1 − spread/100)`), demo caps, severity bands,
FX signal thresholds. Full formulas + worked example in `docs/FINANCIAL_MODEL.md`.

## Staff sign-in & hidden admin console

The public demo needs no sign-in. Staff can open `#/sign-in` directly (it is **not**
linked from any public navigation) and manage the demo from `#/admin/*`:

Overview · Content · Corridors · Providers · FX Data · ScamShield Rules ·
Tuition Seeds · Vault · Users · Audit Log · Settings.

**Authentication mode: B — clearly labeled demo sign-in.** The three demo accounts
(`owner@`/`editor@`/`viewer@probaho.demo`, password `demo1234`) are printed on the
sign-in screen — they are public, not secrets. The session lives only in the tab's
memory (a refresh signs you out). Role flags are demo conveniences, not a security
boundary: a static site cannot do real authorization, and this demo never claims it
can. Admin edits are overrides on the seed data (restorable to defaults); every
admin action is written to a local demo audit log. Full spec: `docs/ADMIN_PORTAL_SPEC.md`;
trust boundaries: `docs/SECURITY_MODEL.md`.

## Privacy & security notes

Planner data, your drafts, admin overrides and the local audit log persist in
`localStorage` (`probaho-titan-v1`, versioned). **Never stored:** pasted message
text, API keys, passwords, the demo session. See `docs/SECURITY_MODEL.md`.

## Known limitations

- Gemini integration **unverified** (no key in this environment) — demo never needs it.
- Screen-reader pass and print-to-PDF not yet executed; semantic markup + print CSS in place.
- No Lighthouse measurement taken (no tooling); fast by construction.

## Source verification status

No market statistics, testimonials, partnerships, or certifications are claimed anywhere in
the product — so there is nothing to verify. The original concept's "US$27bn / 5–8%" figures
were deliberately **excluded** from the UI per the no-fabrication rule.

## Project docs

`PROJECT_STATE.md` · `DEMO_SCRIPT.md` · `QA_REPORT.md` ·
`docs/{PRODUCT_SPEC,FINANCIAL_MODEL,DESIGN_SYSTEM,SECURITY_MODEL,ADMIN_PORTAL_SPEC,QA_PLAN,DECISIONS,DEMO_FLOW}.md`
