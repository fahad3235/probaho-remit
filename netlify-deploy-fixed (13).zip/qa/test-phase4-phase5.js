/**
 * Phase 4 & Phase 5 Comprehensive QA Test Suite
 * Tests Admin Portal endpoints, RBAC, Auditor Read-Only enforcement,
 * Immutable Audit Logs, and Phase 5 PSP Webhook Idempotency.
 */

const http = require('http');

function request(path, options = {}) {
  return new Promise((resolve, reject) => {
    const opt = {
      hostname: '127.0.0.1',
      port: 3000,
      path: path,
      method: options.method || 'GET',
      headers: options.headers || {}
    };

    if (options.body) {
      opt.headers['Content-Type'] = 'application/json';
    }

    const req = http.request(opt, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let parsed = null;
        try { parsed = JSON.parse(data); } catch (e) { parsed = data; }
        resolve({ status: res.statusCode, headers: res.headers, body: parsed });
      });
    });

    req.on('error', reject);
    if (options.body) {
      req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    }
    req.end();
  });
}

async function runTests() {
  console.log('--- Starting Phase 4 & 5 Verification Suite ---');
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${message}`);
      failed++;
    }
  }

  try {
    // 1. Staff Authentication
    console.log('\n1. Testing Staff Authentication & RBAC Tokens');
    const superAdminLogin = await request('/api/auth/staff-login', {
      method: 'POST',
      body: { email: 'owner@probaho.demo', password: 'demo1234', mfa_code: '123456' }
    });
    assert(superAdminLogin.status === 200 && superAdminLogin.body.session, 'Super Admin login successful with session token');
    const adminToken = superAdminLogin.body.session.token;

    const auditorLogin = await request('/api/auth/staff-login', {
      method: 'POST',
      body: { email: 'auditor@probaho.demo', password: 'demo1234', mfa_code: '123456' }
    });
    assert(auditorLogin.status === 200 && auditorLogin.body.session, 'Auditor login successful with session token');
    const auditorToken = auditorLogin.body.session.token;

    // 2. Admin Dashboard KPIs
    console.log('\n2. Testing /api/admin/dashboard-kpis');
    const unauthKpis = await request('/api/admin/dashboard-kpis');
    assert(unauthKpis.status === 403, 'Unauthenticated request to dashboard-kpis returns 403 Forbidden');

    const kpis = await request('/api/admin/dashboard-kpis', {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    assert(kpis.status === 200 && kpis.body.ok, 'Admin can fetch dashboard KPIs');
    assert(typeof kpis.body.kpis.transfers_today === 'number', 'KPIs include transfers_today count');
    assert(typeof kpis.body.kpis.volume_today_bdt === 'number', 'KPIs include volume_today_bdt');
    assert(typeof kpis.body.kpis.success_rate === 'number', 'KPIs include success_rate');
    assert(typeof kpis.body.kpis.pending_kyc_count === 'number', 'KPIs include pending_kyc_count');

    // 3. Admin Users Directory
    console.log('\n3. Testing /api/admin/users');
    const usersRes = await request('/api/admin/users', {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    assert(usersRes.status === 200 && Array.isArray(usersRes.body.users), 'Admin can list users directory');
    const userToTest = usersRes.body.users[0];
    assert(userToTest && userToTest.id, 'Users directory returns profile details');

    // 4. Auditor Read-Only Enforcement on User Actions
    console.log('\n4. Testing Auditor Role Read-Only Enforcement');
    const auditorAction = await request(`/api/admin/users/${userToTest.id}/action`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${auditorToken}` },
      body: { action: 'suspend' }
    });
    assert(auditorAction.status === 403, 'Auditor mutation on user is blocked (403 Read-Only)');

    // 5. Admin User Mutation & Audit Logging
    console.log('\n5. Testing Super Admin User Action & Audit Trail');
    const adminAction = await request(`/api/admin/users/${userToTest.id}/action`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${adminToken}` },
      body: { action: 'suspend', note: 'Compliance check review required' }
    });
    assert(adminAction.status === 200 && adminAction.body.ok, 'Super admin can execute user action');

    // Restore user
    await request(`/api/admin/users/${userToTest.id}/action`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${adminToken}` },
      body: { action: 'unsuspend', note: 'Restored active status' }
    });

    // 6. Transfer Actions (Retry Payout / Refund / Cancel)
    console.log('\n6. Testing /api/admin/transfers/:id/action');
    // Login as user to create transfer
    const userLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { email: 'fahad@probaho.demo', password: 'demo1234' }
    });
    assert(userLogin.status === 200 && userLogin.body.session, 'User login successful');
    const userToken = userLogin.body.session.token;

    // First create a transfer to act upon
    const txCreate = await request('/api/transfers', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}` },
      body: {
        idempotency_key: `test_admin_tx_${Date.now()}`,
        beneficiary_id: 'b0000000-0000-0000-0000-000000000001',
        send_amount: 100,
        send_currency: 'CNY',
        receive_amount: 1675.27,
        receive_currency: 'BDT',
        fx_rate: 16.7527,
        corridor: 'CNY_BDT',
        payout_method: 'bkash',
        account_identifier: '01812345678'
      }
    });
    assert(txCreate.status === 201 && txCreate.body.transfer, 'Created test transfer via /api/transfers');
    const txId = txCreate.body.transfer.id;

    // Auditor cannot mutate transfer
    const auditorTxAction = await request(`/api/admin/transfers/${txId}/action`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${auditorToken}` },
      body: { action: 'refund' }
    });
    assert(auditorTxAction.status === 403, 'Auditor cannot mutate transfer (403)');

    // Admin can refund transfer
    const adminTxRefund = await request(`/api/admin/transfers/${txId}/action`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${adminToken}` },
      body: { action: 'refund' }
    });
    assert(adminTxRefund.status === 200 && adminTxRefund.body.transfer.status === 'refunded', 'Admin can trigger refund action');

    // 7. Admin Reports
    console.log('\n7. Testing /api/admin/reports');
    const reportsRes = await request('/api/admin/reports', {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    assert(reportsRes.status === 200 && reportsRes.body.reports, 'Admin can fetch settlement & volume reports');
    assert(typeof reportsRes.body.reports.total_volume_bdt === 'number', 'Reports contain total_volume_bdt');
    assert(Array.isArray(reportsRes.body.reports.corridors), 'Reports contain corridor volumes');

    // 8. Audit Log Immutability
    console.log('\n8. Testing Audit Log Immutability');
    const deleteAudit = await request('/api/admin/audit-log', {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    assert(deleteAudit.status === 405, 'DELETE /api/admin/audit-log rejected with 405 Method Not Allowed');

    const updateAudit = await request('/api/admin/audit-log', {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${adminToken}` },
      body: { id: 'audit-1', action: 'tampered' }
    });
    assert(updateAudit.status === 405, 'PUT /api/admin/audit-log rejected with 405 Method Not Allowed');

    // 9. Phase 5 Money Movement: PSP Webhooks Idempotency
    console.log('\n9. Testing Phase 5 PSP Webhook Idempotency & Status Progression');
    const pspEventId = `evt_psp_qa_${Date.now()}`;
    const pspWebhook1 = await request('/api/webhooks/psp', {
      method: 'POST',
      headers: { 'x-psp-signature': 'sig_hmac_sha256_mock' },
      body: {
        event_id: pspEventId,
        transfer_id: txId,
        psp_reference: `PSP_REF_${txId}`,
        status: 'delivered'
      }
    });
    assert(pspWebhook1.status === 200 && pspWebhook1.body.processed === true, 'First PSP webhook updates transfer status');

    // Replay exact same webhook
    const pspWebhook2 = await request('/api/webhooks/psp', {
      method: 'POST',
      headers: { 'x-psp-signature': 'sig_hmac_sha256_mock' },
      body: {
        event_id: pspEventId,
        transfer_id: txId,
        psp_reference: `PSP_REF_${txId}`,
        status: 'delivered'
      }
    });
    assert(pspWebhook2.status === 200 && pspWebhook2.body.duplicate_event === true, 'Replayed PSP webhook detected as duplicate and idempotent');

    // 10. Copilot API with Grounded Meta Llama 3.2
    console.log('\n10. Testing Grounded Copilot Local LLM Endpoint');
    const copilotRes = await request('/api/copilot/chat', {
      method: 'POST',
      body: { message: 'How do I send money to my family in Bangladesh?' }
    });
    assert(copilotRes.status === 200 && copilotRes.body.reply, 'Copilot endpoint returns valid structured response');
    assert(copilotRes.body.reply.model.includes('Meta Llama 3.2'), 'Copilot identifies as Meta Llama 3.2 quantized model');
    assert(['Ishan Ahmed', 'Fahad Ahmed'].includes(copilotRes.body.reply.groundedUser), 'Copilot is grounded on user identity');

    console.log(`\n========================================`);
    console.log(`Phase 4 & 5 Test Results: ${passed} Passed, ${failed} Failed`);
    console.log(`========================================\n`);

    if (failed > 0) process.exit(1);
    process.exit(0);
  } catch (err) {
    console.error('Test Suite encountered an unexpected error:', err);
    process.exit(1);
  }
}

runTests();
