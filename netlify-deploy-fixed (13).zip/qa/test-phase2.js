/**
 * qa/test-phase2.js — Phase 2 Public Website Fixes Verification Suite
 * Tests all Phase 2 deliverables against live endpoints:
 * 1. Ungated public landing page & dynamic SEO meta/title tags.
 * 2. Fee table API (/api/fees) reading approved fee_schedules & providers.
 * 3. Corridors API (/api/corridors) reading supported routes & limits from DB.
 * 4. Support tickets API (/api/support/tickets) creating real DB tickets with audit logging.
 * 5. Language preference API (/api/profiles/lang) sync.
 * 6. Legal pages and zero admin leaks on public surfaces.
 */

const http = require('http');

function request(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const reqHeaders = {
      'Content-Type': 'application/json',
      ...headers
    };
    if (data) reqHeaders['Content-Length'] = Buffer.byteLength(data);

    const req = http.request({
      hostname: '127.0.0.1',
      port: 3000,
      path: path,
      method: method,
      headers: reqHeaders
    }, (res) => {
      let resBody = '';
      res.on('data', chunk => resBody += chunk);
      res.on('end', () => {
        let parsed = null;
        try { parsed = JSON.parse(resBody); } catch (e) { parsed = resBody; }
        resolve({ status: res.statusCode, data: parsed, headers: res.headers });
      });
    });

    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function runPhase2Tests() {
  console.log('====================================================');
  console.log('   PROBAHO REMIT — PHASE 2 QA ACCEPTANCE SUITE      ');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // ----------------------------------------------------
    // TEST 1: Ungated Public Landing Page & Static Assets
    // ----------------------------------------------------
    console.log('[1/5] Testing Ungated Public Landing Assets & Metadata...');
    const htmlRes = await request('GET', '/');
    assert(htmlRes.status === 200, 'Landing page serves HTTP 200 OK without requiring login');
    assert(htmlRes.data.includes('Probaho Remit'), 'HTML contains Probaho Remit branding');
    assert(htmlRes.data.includes('langToggleBtn'), 'HTML contains dynamic language toggle button');
    assert(htmlRes.data.includes('fees.js'), 'HTML loads fees.js module');
    assert(htmlRes.data.includes('corridors.js'), 'HTML loads corridors.js module');
    assert(htmlRes.data.includes('legal.js'), 'HTML loads legal.js module');

    // ----------------------------------------------------
    // TEST 2: Corridors API (/api/corridors)
    // ----------------------------------------------------
    console.log('\n[2/5] Testing Corridors API (/api/corridors)...');
    const corridorsRes = await request('GET', '/api/corridors');
    assert(corridorsRes.status === 200 && corridorsRes.data.ok, 'Corridors endpoint returns HTTP 200 OK');
    assert(Array.isArray(corridorsRes.data.corridors) && corridorsRes.data.corridors.length >= 3, 'Returns list of supported corridors from DB');
    const gb = corridorsRes.data.corridors.find(c => c.id === 'GB-BD');
    assert(gb && gb.max_amount >= 500000, 'GB-BD corridor contains active status and limits from DB');
    assert(Array.isArray(gb.payout_methods) && gb.payout_methods.includes('bkash'), 'Corridor lists supported payout methods (e.g. bkash)');

    // ----------------------------------------------------
    // TEST 3: Fee Schedules API (/api/fees)
    // ----------------------------------------------------
    console.log('\n[3/5] Testing Fee Schedules API (/api/fees)...');
    const feesRes = await request('GET', '/api/fees');
    assert(feesRes.status === 200 && feesRes.data.ok, 'Fee schedules endpoint returns HTTP 200 OK');
    assert(Array.isArray(feesRes.data.fees) && feesRes.data.fees.length >= 3, 'Returns approved fee schedules');
    const feeItem = feesRes.data.fees[0];
    assert(feeItem.schedule && typeof feeItem.schedule.config === 'object', 'Includes approved schedule config (base fee & margin)');
    assert(Array.isArray(feeItem.providers) && feeItem.providers.length > 0, 'Includes active providers with fee % and FX margin');

    // ----------------------------------------------------
    // TEST 4: Support Ticket Creation (/api/support/tickets)
    // ----------------------------------------------------
    console.log('\n[4/5] Testing Real Support Ticket Submission (/api/support/tickets)...');
    const ticketRes = await request('POST', '/api/support/tickets', {
      email: 'student.applicant@gmail.com',
      subject: 'Inquiry regarding China-to-BD semester fee remittance',
      message: 'Need confirmation on university tuition documents required for Tier 2 KYC limit.'
    });
    assert(ticketRes.status === 201 && ticketRes.data.ok, 'Support ticket created with HTTP 201 Created');
    assert(ticketRes.data.ticket && ticketRes.data.ticket.id, 'Returns real generated Ticket ID from DB');
    assert(ticketRes.data.ticket.status === 'open', 'New ticket initialized with status "open"');

    // ----------------------------------------------------
    // TEST 5: Language Preference Sync (/api/profiles/lang)
    // ----------------------------------------------------
    console.log('\n[5/5] Testing Language Preference Sync (/api/profiles/lang)...');
    const langRes = await request('PUT', '/api/profiles/lang', {
      preferred_lang: 'bn'
    });
    assert(langRes.status === 200 && langRes.data.preferred_lang === 'bn', 'Language preference successfully synced to "bn" (Bangla)');

    console.log('\n====================================================');
    console.log(`PHASE 2 QA SUMMARY: ${passed} PASSED, ${failed} FAILED`);
    console.log('====================================================\n');

    if (failed > 0) {
      process.exit(1);
    } else {
      process.exit(0);
    }
  } catch (err) {
    console.error('Fatal error during Phase 2 QA:', err);
    process.exit(1);
  }
}

runPhase2Tests();
