/**
 * qa/test-phase3.js — Phase 3 (User Portal) Acceptance & Regression Test Suite
 * Tests all requirements from PROBAHO REMIT Master Plan Phase 3:
 * 1. User Authentication & Profile Retrieval
 * 2. KYC Onboarding & Tier Quota calculation (/api/kyc/me, /api/kyc/submit)
 * 3. Beneficiaries CRUD (/api/beneficiaries) with BD Phone & Bank validation
 * 4. Guaranteed FX Rate Quote with 60s lock (/api/transfers/quote)
 * 5. Daily Tier Limit Enforcement (over-limit 403 with upgrade_required)
 * 6. Idempotent Transfer Order Creation (/api/transfers)
 * 7. Append-only Timeline Tracking (/api/transfers/:id)
 * 8. Transfer Dispute Intake (/api/transfers/:id/dispute -> support_tickets)
 * 9. Multi-session tracking & "Sign Out Everywhere" (/api/settings/signout-all)
 */

const http = require('http');

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`  ✓ PASS: ${message}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${message}`);
    failed++;
  }
}

function request(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = 'Bearer ' + token;
    if (payload) headers['Content-Length'] = Buffer.byteLength(payload);

    const req = http.request({
      hostname: '127.0.0.1',
      port: 3000,
      path: path,
      method: method,
      headers: headers
    }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        let json = {};
        try { json = JSON.parse(data); } catch (e) { json = { raw: data }; }
        resolve({ status: res.statusCode, data: json });
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function runPhase3Tests() {
  console.log('====================================================');
  console.log('RUNNING PHASE 3 (USER PORTAL) ACCEPTANCE SUITE');
  console.log('====================================================\n');

  // TEST 1: User Login & Profile
  console.log('[1/9] Testing User Login & Profile Retrieval...');
  const loginRes = await request('POST', '/api/auth/login', {
    email: 'fahad@probaho.demo',
    password: 'demo1234'
  });
  assert(loginRes.status === 200, 'User login succeeds with HTTP 200');
  assert(loginRes.data.session && loginRes.data.session.token, 'Session token issued');
  const token = loginRes.data.session.token;

  const profRes = await request('GET', '/api/profiles/me', null, token);
  assert(profRes.status === 200, 'Profile retrieval succeeds with HTTP 200');
  assert(profRes.data.profile.email === 'fahad@probaho.demo', 'Profile matches authenticated user');

  // TEST 2: KYC Status & Daily Limit Quota
  console.log('\n[2/9] Testing KYC Status & Tier Limits (/api/kyc/me)...');
  const kycRes = await request('GET', '/api/kyc/me', null, token);
  assert(kycRes.status === 200, 'KYC status query returns HTTP 200');
  assert(kycRes.data.kyc_level === 'basic', 'User starts at Tier 1 (Basic KYC)');
  assert(kycRes.data.daily_limit === 50000, 'Tier 1 daily limit is ৳50,000 BDT');
  assert(typeof kycRes.data.spent_today === 'number', 'Spent today is calculated');
  assert(typeof kycRes.data.remaining_today === 'number', 'Remaining daily quota is calculated');

  // TEST 3: KYC Bundle Submission
  console.log('\n[3/9] Testing KYC Bundle Submission & Resubmission...');
  const subRes = await request('POST', '/api/kyc/submit', {
    doc_type: 'passport',
    doc_front_url: '/storage/v1/object/authenticated/kyc-docs/demo_front.jpg',
    selfie_url: '/storage/v1/object/authenticated/kyc-docs/demo_selfie.jpg'
  }, token);
  assert(subRes.status === 200, 'KYC bundle submit returns HTTP 200');
  assert(subRes.data.submission.status === 'pending', 'KYC submission placed into pending review');

  // TEST 4: Beneficiaries CRUD
  console.log('\n[4/9] Testing Beneficiaries CRUD & Validation...');
  const listBens = await request('GET', '/api/beneficiaries', null, token);
  assert(listBens.status === 200, 'Beneficiaries list query returns HTTP 200');
  assert(Array.isArray(listBens.data.beneficiaries), 'Beneficiaries returns an array');
  const initialCount = listBens.data.beneficiaries.length;

  // Invalid BD phone check
  const badPhoneRes = await request('POST', '/api/beneficiaries', {
    name: 'Invalid Test',
    phone: '12345',
    payout_method: 'bkash'
  }, token);
  assert(badPhoneRes.status === 400, 'Invalid BD phone rejected with HTTP 400');

  // Valid bKash beneficiary
  const newBkash = await request('POST', '/api/beneficiaries', {
    name: 'Tarek Masud',
    phone: '+8801711223344',
    payout_method: 'bkash',
    relationship: 'Family'
  }, token);
  assert(newBkash.status === 201, 'Valid bKash beneficiary created with HTTP 201');
  assert(newBkash.data.beneficiary.name === 'Tarek Masud', 'Beneficiary name matches');
  const tarekId = newBkash.data.beneficiary.id;

  // Valid Bank beneficiary
  const newBank = await request('POST', '/api/beneficiaries', {
    name: 'BRAC University Accounts',
    payout_method: 'bank',
    bank_name: 'BRAC Bank PLC',
    branch_name: 'Mohakhali Branch',
    account_number: '1501209988776',
    relationship: 'Education Tuition'
  }, token);
  assert(newBank.status === 201, 'Valid Bank beneficiary created with HTTP 201');
  assert(newBank.data.beneficiary.bank_name === 'BRAC Bank PLC', 'Bank name saved');

  // TEST 5: Live FX Rate Quote with 60s Lock
  console.log('\n[5/9] Testing Live FX Rate Quote with 60s Lock (/api/transfers/quote)...');
  const quoteRes = await request('POST', '/api/transfers/quote', {
    amount: 1000,
    corridor: 'CN-BD'
  }, token);
  assert(quoteRes.status === 200, 'Live quote returns HTTP 200');
  assert(quoteRes.data.quote.send_currency === 'CNY', 'Send currency is CNY');
  assert(quoteRes.data.quote.receive_currency === 'BDT', 'Receive currency is BDT');
  assert(Number(quoteRes.data.quote.receive_amount) > 10000, 'Receive amount computed with positive rate');
  assert(!!quoteRes.data.quote.fx_locked_until, '60-second fx_locked_until timestamp provided');

  // TEST 6: Tier Limit Enforcement
  console.log('\n[6/9] Testing Daily KYC Tier Limit Enforcement on Transfers...');
  // 5,000 CNY is approx ৳84,000 BDT, which exceeds Tier 1 limit of ৳50,000
  const overLimitRes = await request('POST', '/api/transfers', {
    idempotency_key: 'qa-tier-overlimit-' + Date.now(),
    beneficiary_id: tarekId,
    send_currency: 'CNY',
    send_amount: 5000,
    receive_amount: 83763.50,
    fx_rate: 16.7527
  }, token);
  assert(overLimitRes.status === 403, 'Transfer exceeding daily tier limit is rejected with HTTP 403');
  assert(overLimitRes.data.upgrade_required === true, 'Response specifies upgrade_required: true');

  // TEST 7: Idempotent Transfer Creation & Event Timeline
  console.log('\n[7/9] Testing Transfer Order Creation & Idempotency (/api/transfers)...');
  const validKey = 'qa-idemp-' + Date.now();
  const txCreateRes = await request('POST', '/api/transfers', {
    idempotency_key: validKey,
    beneficiary_id: tarekId,
    send_currency: 'CNY',
    send_amount: 500,
    receive_amount: 8376.35,
    fx_rate: 16.7527,
    payment_method: 'Alipay',
    purpose: 'Family Support'
  }, token);
  assert(txCreateRes.status === 201, 'Valid transfer order created with HTTP 201');
  assert(txCreateRes.data.transfer && txCreateRes.data.transfer.id, 'Transfer object returned');
  assert(Array.isArray(txCreateRes.data.events) && txCreateRes.data.events.length >= 3, 'Initial events timeline created');
  const createdTxId = txCreateRes.data.transfer.id;

  // Replay with identical idempotency_key
  const replayRes = await request('POST', '/api/transfers', {
    idempotency_key: validKey,
    beneficiary_id: tarekId,
    send_currency: 'CNY',
    send_amount: 500
  }, token);
  assert(replayRes.status === 200, 'Replayed transfer returns HTTP 200');
  assert(replayRes.data.idempotent_replayed === true, 'Response marks idempotent_replayed: true');
  assert(replayRes.data.transfer.id === createdTxId, 'Same transfer record returned without duplicate');

  // TEST 8: Transfer Timeline & Dispute Intake
  console.log('\n[8/9] Testing Single Transfer Timeline & Dispute Intake...');
  const txDetailRes = await request('GET', '/api/transfers/' + createdTxId, null, token);
  assert(txDetailRes.status === 200, 'Transfer detail query returns HTTP 200');
  assert(txDetailRes.data.events.some(e => e.status === 'funded'), 'Events include funded step');
  assert(txDetailRes.data.events.some(e => e.status === 'aml_cleared'), 'Events include AML cleared step');
  assert(txDetailRes.data.events.some(e => e.status === 'dispatched'), 'Events include dispatched step');

  // Open Dispute
  const dispRes = await request('POST', '/api/transfers/' + createdTxId + '/dispute', {
    reason: 'Delayed wallet notification confirmation'
  }, token);
  assert(dispRes.status === 201, 'Dispute filed successfully with HTTP 201');
  assert(dispRes.data.ticket && dispRes.data.ticket.transfer_id === createdTxId, 'Support ticket linked to transfer');

  // TEST 9: Active Sessions & Sign Out Everywhere
  console.log('\n[9/9] Testing Active Sessions & "Sign Out Everywhere"...');
  const sessRes = await request('GET', '/api/settings/sessions', null, token);
  assert(sessRes.status === 200, 'Sessions list query returns HTTP 200');
  assert(Array.isArray(sessRes.data.sessions) && sessRes.data.sessions.length >= 1, 'Active session found');

  const signoutAllRes = await request('POST', '/api/settings/signout-all', null, token);
  assert(signoutAllRes.status === 200, 'Sign out everywhere returns HTTP 200');

  // Verify token is now invalidated
  const invalidQuery = await request('GET', '/api/profiles/me', null, token);
  assert(invalidQuery.status === 401, 'Old session token is invalidated across the board (HTTP 401)');

  console.log('\n====================================================');
  console.log(`PHASE 3 QA SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) process.exit(1);
}

runPhase3Tests().catch(err => {
  console.error('Fatal error during test run:', err);
  process.exit(1);
});
