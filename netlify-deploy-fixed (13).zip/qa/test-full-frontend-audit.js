/**
 * qa/test-full-frontend-audit.js
 * Comprehensive automated audit of all frontend assets, scripts, routes, and API linkages.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let passed = 0;
let failed = 0;

function assert(condition, testName, detail = '') {
  if (condition) {
    console.log(`  ✅ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${testName} ${detail ? '(' + detail + ')' : ''}`);
    failed++;
  }
}

function fetchLocal(pathStr) {
  return new Promise((resolve, reject) => {
    http.get(`http://127.0.0.1:3000${pathStr}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    }).on('error', reject);
  });
}

async function runAudit() {
  console.log('\n====================================================');
  console.log('   PROBAHO REMIT — COMPREHENSIVE FRONTEND AUDIT     ');
  console.log('====================================================\n');

  // 1. AUDIT INDEX.HTML ASSETS
  console.log('[1/4] Auditing all script and stylesheet tags in index.html...');
  const indexHtml = fs.readFileSync('index.html', 'utf8');

  // Extract all stylesheets
  const cssMatches = [...indexHtml.matchAll(/<link\s+rel="stylesheet"\s+href="([^"]+)"/g)];
  for (const match of cssMatches) {
    const href = match[1];
    const res = await fetchLocal(`/${href}`);
    assert(res.status === 200 && res.body.length > 50, `Stylesheet loaded: ${href} (HTTP 200, ${res.body.length} bytes)`);
  }

  // Extract all script tags
  const jsMatches = [...indexHtml.matchAll(/<script\s+src="([^"]+)"/g)];
  for (const match of jsMatches) {
    const src = match[1];
    const res = await fetchLocal(`/${src}`);
    assert(res.status === 200 && res.body.length > 20, `Script loaded: ${src} (HTTP 200, ${res.body.length} bytes)`);
  }

  // 2. AUDIT ROUTER CONFIGURATION & MODULE EXPORTS
  console.log('\n[2/4] Auditing all Router ROUTES and exported modules...');
  const routerCode = fs.readFileSync('js/router.js', 'utf8');
  const routePaths = [...routerCode.matchAll(/path:"([^"]+)",\s*mod:"([^"]+)"/g)];

  assert(routePaths.length >= 25, `Found ${routePaths.length} registered routes in Router`);

  // Build a simulated browser environment to execute all modules
  const virtualDOM = {
    window: {
      addEventListener: () => {},
      removeEventListener: () => {}
    },
    addEventListener: () => {},
    removeEventListener: () => {},
    document: {
      title: '',
      documentElement: {
        style: { setProperty: () => {} }
      },
      addEventListener: () => {},
      removeEventListener: () => {},
      createElement: (tag) => ({
        tagName: tag,
        setAttribute: () => {},
        removeAttribute: () => {},
        classList: { add: () => {}, remove: () => {}, toggle: () => {} },
        appendChild: () => {},
        removeChild: () => {},
        addEventListener: () => {},
        querySelector: () => null,
        querySelectorAll: () => [],
        style: {}
      }),
      activeElement: null,
      getElementById: () => ({
        innerHTML: '',
        textContent: '',
        style: {},
        classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false },
        setAttribute: () => {},
        removeAttribute: () => {},
        addEventListener: () => {},
        appendChild: () => {},
        querySelector: () => null,
        querySelectorAll: () => []
      }),
      querySelector: () => null,
      querySelectorAll: () => []
    },
    location: { hash: '#/' },
    localStorage: {
      _data: {},
      getItem(k) { return this._data[k] || null; },
      setItem(k, v) { this._data[k] = String(v); },
      removeItem(k) { delete this._data[k]; },
      clear() { this._data = {}; }
    },
    console: console,
    setTimeout: (fn, ms) => setTimeout(fn, ms),
    clearTimeout: (id) => clearTimeout(id),
    setInterval: (fn, ms) => setInterval(fn, ms),
    clearInterval: (id) => clearInterval(id),
    fetch: () => Promise.resolve({ json: () => Promise.resolve({}) })
  };
  virtualDOM.window = virtualDOM;
  virtualDOM.global = virtualDOM;

  const sandbox = vm.createContext(virtualDOM);

  // Load scripts into sandbox
  for (const match of jsMatches) {
    const src = match[1];
    const code = fs.readFileSync(src, 'utf8');
    try {
      vm.runInContext(code, sandbox, { filename: src });
    } catch (err) {
      assert(false, `Execution error in script: ${src}`, err.message);
    }
  }

  // Check each route's module exists and has render method
  for (const r of routePaths) {
    const p = r[1];
    const modName = r[2];
    const mod = sandbox[modName];
    assert(!!mod && typeof mod.render === 'function', `Route ${p} maps to valid module ${modName}.render()`);
  }

  // 3. AUDIT ALL LIVE API ENDPOINTS
  console.log('\n[3/4] Auditing all API endpoints referenced by frontend...');
  const endpoints = [
    { method: 'GET', path: '/api/config' },
    { method: 'GET', path: '/api/corridors' },
    { method: 'GET', path: '/api/fees' },
    { method: 'POST', path: '/api/transfers/quote', body: { amount: 1000, corridor: 'CN-BD' } }
  ];

  for (const ep of endpoints) {
    const res = await new Promise(resolve => {
      const req = http.request(`http://127.0.0.1:3000${ep.path}`, {
        method: ep.method,
        headers: { 'Content-Type': 'application/json' }
      }, r => {
        let b = '';
        r.on('data', chunk => b += chunk);
        r.on('end', () => resolve({ status: r.statusCode, data: JSON.parse(b || '{}') }));
      });
      if (ep.body) req.write(JSON.stringify(ep.body));
      req.end();
    });
    assert(res.status === 200, `Endpoint ${ep.method} ${ep.path} returns HTTP 200`);
  }

  // 4. SUMMARY
  console.log('\n====================================================');
  console.log(`FRONTEND AUDIT SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================\n');

  if (failed > 0) process.exit(1);
  else process.exit(0);
}

runAudit();
